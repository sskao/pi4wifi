import os
import sys
import logging
sys.path.append("../")
from py3lib.QuGUIclass import *

import py3lib.FileToArray as fil2a
from datetime import datetime

StartVoltage_MIN = 500
StartVoltage_MAX = 1666

VoltageStep_MIN = 200
VoltageStep_MAX = 2000

Scan_Loop_MIN = 1
Scan_Loop_MAX = 2000

Backward_MIN = 0
Backward_MAX = 50

OFFSET_MIN = -15000
OFFSET_MAX = 15000

Run_Loop_MIN = 1
Run_Loop_MAX = 1000

Delay_Time_MIN = 1
Delay_Time_MAX = 1000

Filter_MIN = 1
Filter_MAX = 1000
Filter_Const = 425

DC_Voltage1_MIN = 0
DC_Voltage1_MAX = 1666

DC_Voltage2_MIN = 0
DC_Voltage2_MAX = 4000

Fan_Speed_MIN = 0
Fan_Speed_MAX = 3000

AVG_time_MIN = 1
AVG_time_MAX = 100

Threshold_MIN = -10*1000
Threshold_MAX = 10*1000

Noise_MIN = 1
Noise_MAX = 100

MASS_CENTER_MIN = 0
MASS_CENTER_MAX = 1000
MASS_RANGE_MIN = 0.1
MASS_RANGE_MAX = 100
MASS_RANGE_STEP = 0.1

FONTSIZE = 10

TITLE_TEXT = " iAnalyzer Inc. Ion Mobility Spectrometer"
LOGO_FILENAME = "set/logo.png"

class Peak_Info_Group(QGroupBox):
    def __init__(self, parent= None):
        super(Peak_Info_Group, self).__init__(parent)
        self.setTitle("Peak Info")
        self.peak_pos = QLabel("dv")
        self.peak_area = QLabel("area")
        self.peak1_name = QLabel("peak1")
        self.peak2_name = QLabel("peak2")
        self.peak3_name = QLabel("peak3")
        self.peak4_name = QLabel("peak4")
        self.peak5_name = QLabel("peak5")
        self.peak6_name = QLabel("peak6")

        self.peak1_pos = QLabel("")
        self.peak2_pos = QLabel("")
        self.peak3_pos = QLabel("")
        self.peak4_pos = QLabel("")
        self.peak5_pos = QLabel("")
        self.peak6_pos = QLabel("")

        self.peak1_area = QLabel("")
        self.peak2_area = QLabel("")
        self.peak3_area = QLabel("")
        self.peak4_area = QLabel("")
        self.peak5_area = QLabel("")
        self.peak6_area = QLabel("")
        self.Layout()

        

    def Layout(self):
        layout = QGridLayout()
        layout.addWidget(self.peak_pos,0,1,1,1)
        layout.addWidget(self.peak_area,0,2,1,1)
        layout.addWidget(self.peak1_name,1,0,1,1)
        layout.addWidget(self.peak1_pos,1,1,1,1)
        layout.addWidget(self.peak1_area,1,2,1,1)

        layout.addWidget(self.peak2_name,2,0,1,1)
        layout.addWidget(self.peak2_pos,2,1,1,1)
        layout.addWidget(self.peak2_area,2,2,1,1)

        layout.addWidget(self.peak3_name,3,0,1,1)
        layout.addWidget(self.peak3_pos,3,1,1,1)
        layout.addWidget(self.peak3_area,3,2,1,1)

        layout.addWidget(self.peak4_name,4,0,1,1)
        layout.addWidget(self.peak4_pos,4,1,1,1)
        layout.addWidget(self.peak4_area,4,2,1,1)

        layout.addWidget(self.peak5_name,5,0,1,1)
        layout.addWidget(self.peak5_pos,5,1,1,1)
        layout.addWidget(self.peak5_area,5,2,1,1)

        layout.addWidget(self.peak6_name,6,0,1,1)
        layout.addWidget(self.peak6_pos,6,1,1,1)
        layout.addWidget(self.peak6_area,6,2,1,1)
        self.setLayout(layout)
    
    def clearInfo(self):
        self.peak1_pos.setText("")
        self.peak2_pos.setText("")
        self.peak3_pos.setText("")
        self.peak4_pos.setText("")
        self.peak5_pos.setText("")
        self.peak6_pos.setText("")
        self.peak1_area.setText("")
        self.peak2_area.setText("")
        self.peak3_area.setText("")
        self.peak4_area.setText("")
        self.peak5_area.setText("")
        self.peak6_area.setText("")


class Data_Analysis_Group(QGroupBox):
    def __init__(self, parent=None):
        super(Data_Analysis_Group, self).__init__(parent)
        self.setTitle("Data Analysis")
        self.Threshold = spinBlock("Threshold (mV)", Threshold_MIN, Threshold_MAX)
        self.Width = spinBlock("Width (points)", Noise_MIN, Noise_MAX)
        self.LoadBtn = QPushButton("Load Old Data")
        self.CurrBtn = QPushButton("Use Current Data")
        self.AnaBtn = QPushButton("Peak Analysis")
        self.SaveBtn = QPushButton("Save Result")
        self.PeakInfo = Peak_Info_Group()

        self.CurrBtn.setEnabled(False)
        self.AnaBtn.setEnabled(False)
        self.SaveBtn.setEnabled(False)

        layout = QGridLayout()
        layout.addWidget(self.Threshold,0,0,1,1)
        layout.addWidget(self.Width,0,1,1,1)
        layout.addWidget(self.PeakInfo, 1,0,3,2)
        layout.addWidget(self.LoadBtn,4,0,1,1)
        layout.addWidget(self.CurrBtn,4,1,1,1)
        layout.addWidget(self.AnaBtn,5,0,1,1)
        layout.addWidget(self.SaveBtn,5,1,1,1)
        self.setLayout(layout)
        
class Signal_Read_Group_new(QGroupBox):
    def __init__(self, parent=None):
        super(Signal_Read_Group_new, self).__init__(parent)
        
        self.comport = connectBlock("USB Connection")
        self.FHedit = editBlock("File Header")
        self.Signal = Signal_Read_Group()
        self.runText = QLabel("Run Index = ")
        self.runText.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        self.runIndex = QLabel("0")
        #self.resetBtn = QPushButton("Reset Index")
        self.DCmode = QPushButton("DC mode")
        self.startScan = QPushButton("Start Scan")
        self.stop = QPushButton("Stop")

        self.DCmode.setEnabled(False)
        self.startScan.setEnabled(False)
        self.stop.setEnabled(False)

        w = QWidget()
        self.picout = QLabel(w)
        lg = QPixmap(LOGO_FILENAME)
        logo = lg.scaled(500, 90, Qt.KeepAspectRatio)
        self.picout.setPixmap(logo)

        mainLayout = QGridLayout()
        

        mainLayout.addWidget(self.comport.layout2(),0,0,1,1)
        mainLayout.addWidget(self.FHedit, 0,1,1,1)
        mainLayout.addWidget(self.Signal,0,2,1,1)
        
        mainLayout.addWidget(self.runText,1,0,1,1)
        mainLayout.addWidget(self.runIndex,1,1,1,1)
        mainLayout.addWidget(self.DCmode,2,0,1,1)
        mainLayout.addWidget(self.startScan,2,1,1,1)
        mainLayout.addWidget(self.stop,2,2,1,1)
        mainLayout.addWidget(self.picout,3,0,1,3)
#         mainLayout.setRowStretch(0, 1)
#         mainLayout.setRowStretch(1, 1)
#         mainLayout.setRowStretch(2, 3)
#         mainLayout.setRowStretch(3, 1)
#         mainLayout.setRowStretch(4, 1)
#         mainLayout.setRowStretch(5, 1)
#         mainLayout.setRowStretch(6, 1)
#         mainLayout.setColumnStretch(0, 8)
#         mainLayout.setColumnStretch(1, 1)
#         mainLayout.setColumnStretch(2, 1)
#         mainLayout.setColumnStretch(3, 1)
        self.setLayout(mainLayout)
        
        
        
        

class Data_Text_Group(QGroupBox):
    def __init__(self, parent=None):
        super(Data_Text_Group, self).__init__(parent)
        self.setTitle("Text")

        path = './set/text.txt'
        text=fil2a.setTextToArray(path)

        M_Min=0
        M_Max=300

        self.v1 = QSpinBox()
        self.n1 = QLineEdit()
        self.x1 = QSpinBox()
        self.y1 = QSpinBox()
        self.c1 = QComboBox()

        self.v2 = QSpinBox()
        self.n2 = QLineEdit()
        self.x2 = QSpinBox()
        self.y2 = QSpinBox()
        self.c2 = QComboBox()

        self.v3 = QSpinBox()
        self.n3 = QLineEdit()
        self.x3 = QSpinBox()
        self.y3 = QSpinBox()
        self.c3 = QComboBox()
        
        self.v4 = QSpinBox()
        self.n4 = QLineEdit()
        self.x4 = QSpinBox()
        self.y4 = QSpinBox()
        self.c4 = QComboBox()
        
        self.v5 = QSpinBox()
        self.n5 = QLineEdit()
        self.x5 = QSpinBox()
        self.y5 = QSpinBox()
        self.c5 = QComboBox()
        
        self.v6 = QSpinBox()
        self.n6 = QLineEdit()
        self.x6 = QSpinBox()
        self.y6 = QSpinBox()
        self.c6 = QComboBox()
        
        self.v7 = QSpinBox()
        self.n7 = QLineEdit()
        self.x7 = QSpinBox()
        self.y7 = QSpinBox()
        self.c7 = QComboBox()
        
        self.v8 = QSpinBox()
        self.n8 = QLineEdit()
        self.x8 = QSpinBox()
        self.y8 = QSpinBox()
        self.c8 = QComboBox()

        self.v1.setRange(M_Min,M_Max) 
        self.x1.setRange(M_Min,M_Max) 
        self.y1.setRange(M_Min,M_Max) 

        self.v1.setValue(int(text[0][0]))
        self.n1.setText(str(text[0][1]))
        self.x1.setValue(int(text[0][2]))
        self.y1.setValue(int(text[0][3]))


        self.c1.addItems(['blue','red','yellow','green','black','cyan','magenta'])
        self.c1.setCurrentText(str(text[0][4]))

        # self.c1.setText(str(text[0][4]))
        
        self.v2.setRange(M_Min,M_Max) 
        self.x2.setRange(M_Min,M_Max) 
        self.y2.setRange(M_Min,M_Max) 

        self.v2.setValue(int(text[1][0]))
        self.n2.setText(str(text[1][1]))
        self.x2.setValue(int(text[1][2]))
        self.y2.setValue(int(text[1][3]))

        self.c2.addItems(['blue','red','yellow','green','black','cyan','magenta'])
        self.c2.setCurrentText(str(text[1][4]))
                
        self.v3.setRange(M_Min,M_Max) 
        self.x3.setRange(M_Min,M_Max) 
        self.y3.setRange(M_Min,M_Max) 

        self.v3.setValue(int(text[2][0]))
        self.n3.setText(str(text[2][1]))
        self.x3.setValue(int(text[2][2]))
        self.y3.setValue(int(text[2][3]))

        self.c3.addItems(['blue','red','yellow','green','black','cyan','magenta'])
        self.c3.setCurrentText(str(text[2][4]))
                
        self.v4.setRange(M_Min,M_Max) 
        self.x4.setRange(M_Min,M_Max) 
        self.y4.setRange(M_Min,M_Max) 

        self.v4.setValue(int(text[3][0]))
        self.n4.setText(str(text[3][1]))
        self.x4.setValue(int(text[3][2]))
        self.y4.setValue(int(text[3][3]))

        self.c4.addItems(['blue','red','yellow','green','black','cyan','magenta'])
        self.c4.setCurrentText(str(text[3][4]))
                
        self.v5.setRange(M_Min,M_Max) 
        self.x5.setRange(M_Min,M_Max) 
        self.y5.setRange(M_Min,M_Max) 

        self.v5.setValue(int(text[4][0]))
        self.n5.setText(str(text[4][1]))
        self.x5.setValue(int(text[4][2]))
        self.y5.setValue(int(text[4][3]))

        self.c5.addItems(['blue','red','yellow','green','black','cyan','magenta'])
        self.c5.setCurrentText(str(text[4][4]))
                
        self.v6.setRange(M_Min,M_Max) 
        self.x6.setRange(M_Min,M_Max) 
        self.y6.setRange(M_Min,M_Max) 

        self.v6.setValue(int(text[5][0]))
        self.n6.setText(str(text[5][1]))
        self.x6.setValue(int(text[5][2]))
        self.y6.setValue(int(text[5][3]))

        self.c6.addItems(['blue','red','yellow','green','black','cyan','magenta'])
        self.c6.setCurrentText(str(text[5][4]))
                
        self.v7.setRange(M_Min,M_Max) 
        self.x7.setRange(M_Min,M_Max) 
        self.y7.setRange(M_Min,M_Max) 

        self.v7.setValue(int(text[6][0]))
        self.n7.setText(str(text[6][1]))
        self.x7.setValue(int(text[6][2]))
        self.y7.setValue(int(text[6][3]))
        self.c7.addItems(['blue','red','yellow','green','black','cyan','magenta'])
        self.c7.setCurrentText(str(text[6][4]))
                
        self.v8.setRange(M_Min,M_Max) 
        self.x8.setRange(M_Min,M_Max) 
        self.y8.setRange(M_Min,M_Max) 

        self.v8.setValue(int(text[7][0]))
        self.n8.setText(str(text[7][1]))
        self.x8.setValue(int(text[7][2]))
        self.y8.setValue(int(text[7][3]))
        self.c8.addItems(['blue','red','yellow','green','black','cyan','magenta'])
        self.c8.setCurrentText(str(text[7][4]))
        

        self.TextBtn = QPushButton("Set")
        layout = QGridLayout()
        layout.addWidget(self.v1,0,0,1,1)
        layout.addWidget(self.n1,0,1,1,1)
        layout.addWidget(self.x1,0,2,1,1)
        layout.addWidget(self.y1,0,3,1,1)
        layout.addWidget(self.c1,0,4,1,1)

        layout.addWidget(self.v2,1,0,1,1)
        layout.addWidget(self.n2,1,1,1,1)
        layout.addWidget(self.x2,1,2,1,1)
        layout.addWidget(self.y2,1,3,1,1)
        layout.addWidget(self.c2,1,4,1,1)

        layout.addWidget(self.v3,2,0,1,1)
        layout.addWidget(self.n3,2,1,1,1)
        layout.addWidget(self.x3,2,2,1,1)
        layout.addWidget(self.y3,2,3,1,1)
        layout.addWidget(self.c3,2,4,1,1)
        
        layout.addWidget(self.v4,3,0,1,1)
        layout.addWidget(self.n4,3,1,1,1)
        layout.addWidget(self.x4,3,2,1,1)
        layout.addWidget(self.y4,3,3,1,1)
        layout.addWidget(self.c4,3,4,1,1)
        
        layout.addWidget(self.v5,4,0,1,1)
        layout.addWidget(self.n5,4,1,1,1)
        layout.addWidget(self.x5,4,2,1,1)
        layout.addWidget(self.y5,4,3,1,1)
        layout.addWidget(self.c5,4,4,1,1)
        
        layout.addWidget(self.v6,5,0,1,1)
        layout.addWidget(self.n6,5,1,1,1)
        layout.addWidget(self.x6,5,2,1,1)
        layout.addWidget(self.y6,5,3,1,1)
        layout.addWidget(self.c6,5,4,1,1)
        
        layout.addWidget(self.v7,6,0,1,1)
        layout.addWidget(self.n7,6,1,1,1)
        layout.addWidget(self.x7,6,2,1,1)
        layout.addWidget(self.y7,6,3,1,1)
        layout.addWidget(self.c7,6,4,1,1)
        
        layout.addWidget(self.v8,7,0,1,1)
        layout.addWidget(self.n8,7,1,1,1)
        layout.addWidget(self.x8,7,2,1,1)
        layout.addWidget(self.y8,7,3,1,1)
        layout.addWidget(self.c8,7,4,1,1)
        
        layout.addWidget(self.TextBtn,8,0,1,5)        
        self.setLayout(layout)


class Xic_Group(QGroupBox):
    def __init__(self, parent=None):
        super(Xic_Group, self).__init__(parent)
        self.setTitle("Tic / Xic")
#         self.xicMassCenter = spinBlock("Xic Mass Center", MASS_CENTER_MIN, MASS_CENTER_MAX)
        self.xicMassCenter_label = QLabel("Center")
        self.xicMassCenter = QSpinBox()
        self.xicMassCenter.setRange(MASS_CENTER_MIN, MASS_CENTER_MAX)
        
#         self.xicMassRange = spinBlock("Xic Mass Range", MASS_RANGE_MIN, MASS_RANGE_MAX, True, MASS_RANGE_STEP)
        self.xicMassRange_label = QLabel("Range")
        self.xicMassRange = QDoubleSpinBox()
        self.xicMassRange.setRange(MASS_RANGE_MIN, MASS_RANGE_MAX)        
        self.xicMassRange.setSingleStep(MASS_RANGE_STEP) 
        
#         self.xicThreshold = spinBlock("Xic Threshold (mV)", Threshold_MIN, Threshold_MAX)
        self.xicThreshold_label = QLabel("Threshold")
        self.xicThreshold = QSpinBox()
        self.xicThreshold.setRange(Threshold_MIN, Threshold_MAX)
        
        
#         self.xicWidth = spinBlock("Xic Width (points)", Noise_MIN, Noise_MAX)
        self.xicWidth_label = QLabel("Width")
        self.xicWidth = QSpinBox()
        self.xicWidth.setRange(Noise_MIN, Noise_MAX)
        
        

        layout = QGridLayout()
        
        layout.addWidget(self.xicMassCenter_label,0,0,1,1)
        layout.addWidget(self.xicMassCenter,0,1,1,1)
        layout.addWidget(self.xicMassRange_label,0,2,1,1)
        layout.addWidget(self.xicMassRange,0,3,1,1)
        layout.addWidget(self.xicThreshold_label,0,4,1,1)
        layout.addWidget(self.xicThreshold,0,5,1,1)
        layout.addWidget(self.xicWidth_label,0,6,1,1)
        layout.addWidget(self.xicWidth,0,7,1,1)
        self.setLayout(layout)

class Data_Sampling_Group(QGroupBox):
    def __init__(self, parent=None):
        super(Data_Sampling_Group, self).__init__(parent)
        self.setTitle("Data Sampling")
#         self.frame = QGroupBox("Polarity")
#         self.poBtn1 = QRadioButton("Positive", self.frame)
        self.poBtn1 = QRadioButton("Positive")
        self.poBtn1.setChecked(True)  # select by default
#         self.poBtn2 = QRadioButton("Negative", self.frame)
        self.poBtn2 = QRadioButton("Negative")
#         self.AVG_time = spinBlock("Average Times", AVG_time_MIN, AVG_time_MAX, False, 1)
        self.AVG_time_label = QLabel("Average Times")
        self.AVG_time = QSpinBox()
        self.AVG_time.setRange(AVG_time_MIN, AVG_time_MAX)

#         frameLayout = QHBoxLayout()
#         frameLayout.addWidget(self.poBtn1)
#         frameLayout.addWidget(self.poBtn2)
#         self.frame.setLayout(frameLayout)

        layout = QGridLayout()
#         layout.addWidget(self.frame,0,0,1,1)
        layout.addWidget(self.poBtn1,0,1,1,1)
        layout.addWidget(self.poBtn2,0,2,1,1)

        layout.addWidget(self.AVG_time_label,0,3,1,1)
        layout.addWidget(self.AVG_time,0,4,1,1)
        #layout.addWidget(self.frame3,2,0,1,1)
        self.setLayout(layout)


class Signal_Read_Group(QGroupBox):
    def __init__(self, parent=None):
        super(Signal_Read_Group, self).__init__(parent)
        self.setTitle("Signal Read (mV)")
        self.text = QLabel("0")
        pe = QPalette()
        pe.setColor(QPalette.WindowText,Qt.yellow)
        self.text.setAutoFillBackground(True)
        pe.setColor(QPalette.Window,Qt.black)
        self.text.setPalette(pe)
        self.text.setAlignment(Qt.AlignCenter)
        self.text.setFont(QFont("",16,QFont.Bold))

        # self.checkbox = QCheckBox("Save Raw File")
        self.SaveDataBtn = QPushButton("Save Signal Data")
        self.SaveDataBtn.setEnabled(False)

        layout = QGridLayout()
        layout.addWidget(self.text,0,0,1,1)
        # layout.addWidget(self.checkbox,0,2,1,1)
        layout.addWidget(self.SaveDataBtn,1,0,1,1)
        self.setLayout(layout)


class Fan_Control_Group(QGroupBox):
    def __init__(self, parent=None):
        super(Fan_Control_Group, self).__init__(parent)
        self.setTitle("Fan Control")
#         self.Fan_Speed = spinBlock("Fan Speed Setting (mV)", Fan_Speed_MIN, Fan_Speed_MAX)
        self.Fan_Speed_label = QLabel("Fan Speed Setting (mV)")
        self.Fan_Speed = QSpinBox()
        self.Fan_Speed.setRange(Fan_Speed_MIN, Fan_Speed_MAX)
        
        self.fanLabel1 = QLabel("Fan Speed = ")
        self.fanLabel2 = QLabel("0")
        
        self.FanBtn = QPushButton("Set")
        #---------------------------------------------
        # self.FanBtn.setVisible(False)
        #---------------------------------------------
        self.esiFanBtn = QPushButton("Set ESI and Fan Speed")
        self.esiFanBtn.setEnabled(False)

        self.FanBtn.setEnabled(False)
    
        layout = QGridLayout()
        layout.addWidget(self.Fan_Speed_label,0,0,1,1)
        layout.addWidget(self.Fan_Speed,0,1,1,1)
        layout.addWidget(self.FanBtn,0,2,1,1)
        layout.addWidget(self.fanLabel1,0,3,1,1)
        layout.addWidget(self.fanLabel2,0,4,1,1)

#         layout.addWidget(self.esiFanBtn,0,5,1,1)
    
        
        self.setLayout(layout)


class DC_Voltage_Group(QGroupBox):
    def __init__(self, parent=None):
        super(DC_Voltage_Group, self).__init__(parent)
        self.setTitle("DC Voltage Control")
#         self.DC_Voltage1 = spinBlock("Fixed Voltage (V)", DC_Voltage1_MIN, DC_Voltage1_MAX)
        self.DC_Voltage1_label = QLabel("Fixed Voltage (V)")
        self.DC_Voltage1 = QSpinBox()
        self.DC_Voltage1.setRange(DC_Voltage1_MIN, DC_Voltage1_MAX)
       
#         self.DC_Voltage2 = spinBlock("ESI (V)", DC_Voltage2_MIN, DC_Voltage2_MAX)
        self.DC_Voltage2_label = QLabel("ESI (V)")
        self.DC_Voltage2 = QSpinBox()
        self.DC_Voltage2.setRange(DC_Voltage2_MIN, DC_Voltage2_MAX)
        
        # self.V1_Btn = QPushButton("Set Fixed Voltage")
        self.V2_Btn = QPushButton("Set ESI")
        # self.fixed_label1 = QLabel("Fixed DC = ")
        # self.fixed_label2 = QLabel("0")
        self.esi_label1 = QLabel("ESI = ")
        self.esi_label2 = QLabel("0")
        # self.V1_Btn.setEnabled(False)
        self.V2_Btn.setEnabled(False)

        layout = QGridLayout()
        layout.addWidget(self.DC_Voltage1_label,0,0,1,1)
        layout.addWidget(self.DC_Voltage1,0,1,1,1)
        #layout.addWidget(self.V1_Btn,0,1,1,1)
        #layout.addWidget(self.fixed_label1, 0,2,1,1)
        #layout.addWidget(self.fixed_label2,0,3,1,1)
        layout.addWidget(self.DC_Voltage2_label,0,2,1,1)
        layout.addWidget(self.DC_Voltage2,0,3,1,1)
        layout.addWidget(self.V2_Btn,0,4,1,1)
        layout.addWidget(self.esi_label1,0,5,1,1)
        layout.addWidget(self.esi_label2,0,6,1,1)
        layout.setColumnStretch(0, 1)
        layout.setColumnStretch(1, 1)
        layout.setColumnStretch(2, 1)
        layout.setColumnStretch(3, 1)
        self.setLayout(layout)


class HVScan_Group(QGroupBox):
    def __init__(self, parent=None):
        super(HVScan_Group, self).__init__(parent)
        self.setTitle("High Voltage Scan")
        
#         self.StartVoltage = spinBlock("Start Voltage (V)", StartVoltage_MIN, StartVoltage_MAX)
        self.StartVoltage_label = QLabel("Start Voltage (V)")
        self.StartVoltage = QSpinBox()
        self.StartVoltage.setRange(StartVoltage_MIN, StartVoltage_MAX)
        
#         self.VoltageStep = spinBlock("Voltage Step (mV)", VoltageStep_MIN, VoltageStep_MAX, True, 0.01)
        self.VoltageStep_label = QLabel("Voltage Step (mV)")
        self.VoltageStep = QDoubleSpinBox()
        self.VoltageStep.setRange(StartVoltage_MIN, StartVoltage_MAX)
        self.VoltageStep.setSingleStep(0.01)        
        
#         self.Loop = spinBlock("Total Steps", Scan_Loop_MIN, Scan_Loop_MAX)
        self.Loop_label = QLabel("Total Steps")
        self.Loop = QSpinBox()
        self.Loop.setRange(Scan_Loop_MIN, Scan_Loop_MAX)
        
#         self.Back = spinBlock("Backward points", Backward_MIN, Backward_MAX)
        self.Back_label = QLabel("Backward points")
        self.Back = QSpinBox()
        self.Back.setRange(Backward_MIN, Backward_MAX)
        
#         self.offset = spinBlock("Offset (mV)", OFFSET_MIN, OFFSET_MAX)
        self.offset_label = QLabel("Offset (mV)")
        self.offset = QSpinBox()
        self.offset.setRange(OFFSET_MIN, OFFSET_MAX)
        
#         self.Run_loop = spinBlock("Accumulate Loops", Run_Loop_MIN, Run_Loop_MAX)
        self.Run_loop_label = QLabel("Accumulate Loops")
        self.Run_loop = QSpinBox()
        self.Run_loop.setRange(Run_Loop_MIN, Run_Loop_MAX)
        
#         self.delay = spinBlock("Time delay (ms)", Delay_Time_MIN, Delay_Time_MAX)
        self.delay_label = QLabel("Time delay (ms)")
        self.delay = QSpinBox()
        self.delay.setRange(Delay_Time_MIN, Delay_Time_MAX)
        
#         self.filterFreq = spinBlock("Filter Freq (mHz)", Filter_MIN, Filter_MAX)
        self.filterFreq_label = QLabel("Filter Freq (mHz)")
        self.filterFreq = QSpinBox()
        self.filterFreq.setRange(Filter_MIN, Filter_MAX)
        
        self.checkTic = QCheckBox("Tic / Xic")
        self.checkFilter = QCheckBox("Filter")
        self.checkFilter.setChecked(False)
        self.checkFilter.setEnabled(False)

        
        self.text1 = QLabel("Voltage Out = ")
        self.text2 = QLabel("0 (V)")
        self.turnoff = QPushButton("Turn off all output")
        self.turnoff.setEnabled(False)

#         self.delay.valueChanged.connect(self.update_filter)

        self.layout()

    def layout(self):
        layout = QGridLayout()
        layout.addWidget(self.StartVoltage_label,0,0,1,1)
        layout.addWidget(self.StartVoltage,0,1,1,1)
        layout.addWidget(self.VoltageStep_label,0,2,1,1)
        layout.addWidget(self.VoltageStep,0,3,1,1)
        layout.addWidget(self.Loop_label,1,0,1,1)
        layout.addWidget(self.Loop,1,1,1,1)
        layout.addWidget(self.Back_label,1,2,1,1)
        layout.addWidget(self.Back,1,3,1,1)
        layout.addWidget(self.offset_label,2,0,1,1)
        layout.addWidget(self.offset,2,1,1,1)
        layout.addWidget(self.Run_loop_label,2,2,1,1)
        layout.addWidget(self.Run_loop,2,3,1,1)        
        layout.addWidget(self.delay_label,3,0,1,1)
        layout.addWidget(self.delay,3,1,1,1)        
        layout.addWidget(self.filterFreq_label,3,2,1,1)
        layout.addWidget(self.filterFreq,3,3,1,1)
        
        
        layout.addWidget(self.checkTic,5,0,1,1)
        layout.addWidget(self.checkFilter,5,1,1,1)
        layout.addWidget(self.text1,5,2,1,1)
        layout.addWidget(self.text2,5,3,1,1)
        layout.addWidget(self.turnoff,6,2,1,2)
        self.setLayout(layout)

    def update_filter(self):
        delay_value = float(Filter_Const/self.delay.value())
        if (delay_value < Filter_MAX):
            # print("change filter")
            # print(delay_value)
            self.filterFreq.setRange(Filter_MIN, delay_value)
        else:
            self.filterFreq.setRange(Filter_MIN, Filter_MAX)


class TabPlot(QTabWidget):
    def __init__(self, parent=None):
        super(TabPlot, self).__init__(parent)
        self.tab1 = QWidget()
        # self.tab2 = QWidget()
        self.tab3 = QWidget()
        
        # self.plot1 = outputPlotSize(FONTSIZE)
        #-----------------------------------------------
        self.plot1 = outputPlot()

        

        # Drugs Label
        #------------------------------------------------
        # self.plot1.ax.set_ylabel("Counts")
        # self.plot1.ax.set_xlabel("dv")
        # self.plot1.ax1.set(xlim=(60,100),ylim=(0,1000)) 
        
        # self.plot1.ax2.xaxis.tick_top()
        # self.plot1.ax2.yaxis.tick_right()

        #--Label 到看不見的地方

        self.plot1.ax2.set_yticks([110])

        self.plot1.ax2.set_xticks([0])        

        #----------------------------------

        # self.plot1.ax2.set_xticks([96,104,113,129])
        # self.plot1.ax2.set_xticklabels(['甲基安非他命','喵喵/K他命','Eutylone','K2'],fontsize=14,fontfamily='SimSun', rotation=30)   
        
        self.plot1.ax2.set(xlim=(50,200),ylim=(0,100))      
        
        #----------------------------------------------------------------------------------------------------------------------------
        path = './set/text.txt'
        text=fil2a.setTextToArray(path)

        for j in range(len(text)):
            if (int(text[j][0]) != 0 ) and (str(text[j][4])!= ''):
                self.plot1.ax2.bar([int(text[j][0])],[100],width=4,alpha=.1,color=str(text[j][4]))   
                self.plot1.ax2.text(int(text[j][2]),int(text[j][3]),str(text[j][1]),fontsize=10)         

        #----------------------------------------------------------------------------------------------------------------------------
        # current_dateTime = datetime.now()
        # self.plot1.ax2.text(205,95,current_dateTime.hour,fontsize=14,fontfamily='SimSun')  
        # self.plot1.ax2.text(190,85,'test',fontsize=14,fontfamily='SimSun')  
        
        
        # self.plot1.ax2.bar([96,104,109,129],[100,100,100,100],width=4,alpha=.1)       

        # self.plot1.ax2.text([96,104,109,129],[100,100,100,100],['甲基安非他命','喵喵/K他命','Eutylone','K2'],fontsize=14,fontfamily='SimSun', rotation=30) 
        
        # self.plot1.ax2.text(85,110,'甲基安非他命',fontsize=14,fontfamily='SimSun', rotation=0) 
        # self.plot1.ax2.text(100,106,'喵喵/K他命',fontsize=14,fontfamily='SimSun', rotation=0) 
        # self.plot1.ax2.text(106,102,'Eutylone',fontsize=14,fontfamily='SimSun', rotation=0) 
        # self.plot1.ax2.text(127,102,'K2',fontsize=14,fontfamily='SimSun', rotation=0) 
        #-----------------------------------------------
        
        # self.plot2 = output2Plot()
        self.plot3 = outputPlotSize(FONTSIZE)


        # self.plot2.ax1.set_ylabel("Arbiary Uint")
        # self.plot2.ax2.set_xlabel("Time (s)")
        # self.plot2.ax2.set_ylabel("Arbiary Uint")
        self.addTab(self.tab1,"Single Data")
        # self.addTab(self.tab2,"TIC")
        self.addTab(self.tab3,"Analysis")


        self.Tab1_UI()
        # self.Tab2_UI()
        self.Tab3_UI()



    def Tab1_UI(self):
        layout = QVBoxLayout()
        layout.addWidget(self.plot1)
        self.tab1.setLayout(layout)

    # def Tab2_UI(self):
    #     layout = QVBoxLayout()
    #     layout.addWidget(self.plot2)
    #     self.tab2.setLayout(layout)

    def Tab3_UI(self):
        layout = QVBoxLayout()
        layout.addWidget(self.plot3)
        self.tab3.setLayout(layout)



class TabAll(QTabWidget):
    def __init__(self, parent=None):
        super(TabAll, self).__init__(parent)
        self.tab1 = QWidget()
        self.tab2 = QWidget()
        self.tab3 = QWidget()

        self.tab4 = QWidget()
        self.tab5 = QWidget()
       

        self.HVscan = HVScan_Group()
        self.DCset = DC_Voltage_Group()
        self.Fan = Fan_Control_Group()
        self.DataSampling = Data_Sampling_Group()
        self.TicXic = Xic_Group()
        self.Analysis = Data_Analysis_Group()

        self.DataText = Data_Text_Group()
        self.Signal_new = Signal_Read_Group_new()
        

        self.addTab(self.tab1,"Scan")
        self.addTab(self.tab2,"Setting")
        self.addTab(self.tab3,"Analysis")

        self.addTab(self.tab4,"Text")
        self.addTab(self.tab5,"Signal")
        
    

        self.Tab1_UI()
        self.Tab2_UI()
        self.Tab3_UI()

        self.Tab4_UI()
        self.Tab5_UI()
        

    def Tab1_UI(self):
        layout = QVBoxLayout()
        layout.addWidget(self.HVscan)
        self.tab1.setLayout(layout)

    def Tab2_UI(self):
        layout = QVBoxLayout()
        layout.addWidget(self.DCset)
        layout.addWidget(self.Fan)
        layout.addWidget(self.DataSampling)
        layout.addWidget(self.TicXic)
        self.tab2.setLayout(layout)

    def Tab3_UI(self):
        layout = QVBoxLayout()
        layout.addWidget(self.Analysis)
        self.tab3.setLayout(layout)

    def Tab4_UI(self):
        layout = QVBoxLayout()
        layout.addWidget(self.DataText)
        self.tab4.setLayout(layout)
        
    def Tab5_UI(self):
        layout = QVBoxLayout()
        layout.addWidget(self.Signal_new)
        self.tab5.setLayout(layout)

class Setting(QDialog):
    def __init__(self, parent=None):
        super(Setting, self).__init__(parent)
        
        
        
        self.setWindowTitle('Setting')
    
#         self.comport = connectBlock("USB Connection")
#         #self.plot = output2Plot()
#         # self.tabPlot = TabPlot()
#         self.FHedit = editBlock("File Header")
        self.tabAll = TabAll()
        self.closeBtn = QPushButton("Close")
        
        self.closeBtn.clicked.connect(self.onSettingClosePress)
        #
#         self.Signal = Signal_Read_Group()
#         self.runText = QLabel("Run Index = ")
#         self.runText.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
#         self.runIndex = QLabel("0")
#         #self.resetBtn = QPushButton("Reset Index")
#         self.DCmode = QPushButton("DC mode")
#         self.startScan = QPushButton("Start Scan")
#         self.stop = QPushButton("Stop")
# 
#         self.DCmode.setEnabled(False)
#         self.startScan.setEnabled(False)
#         self.stop.setEnabled(False)
# 
#         w = QWidget()
#         self.picout = QLabel(w)
#         lg = QPixmap(LOGO_FILENAME)
#         logo = lg.scaled(500, 90, Qt.KeepAspectRatio)
#         self.picout.setPixmap(logo)

        self.main_UI()

    def onSettingClosePress(self):
        self.close()

    def main_UI(self):
        
        mainLayout = QGridLayout()
        # mainLayout.addWidget(self.tabPlot,0,0,7,1)
#         mainLayout.addWidget(self.comport.layout2(),0,1,1,1)
#         mainLayout.addWidget(self.FHedit, 0,2,1,2)
        mainLayout.addWidget(self.tabAll,1,1,1,3)
        mainLayout.addWidget(self.closeBtn,2,1,1,1)
#         mainLayout.addWidget(self.Signal,2,1,1,3)
#         mainLayout.addWidget(self.runText,3,1,1,1)
#         mainLayout.addWidget(self.runIndex,3,2,1,1)
#         # mainLayout.addWidget(self.resetBtn,4,3,1,1)
#         mainLayout.addWidget(self.DCmode,4,1,1,1)
#         mainLayout.addWidget(self.startScan,4,2,1,1)
#         mainLayout.addWidget(self.stop,4,3,1,1)
#         mainLayout.addWidget(self.picout,5,1,1,3)
#         mainLayout.setRowStretch(0, 1)
#         mainLayout.setRowStretch(1, 1)
#         mainLayout.setRowStretch(2, 3)
#         mainLayout.setRowStretch(3, 1)
#         mainLayout.setRowStretch(4, 1)
#         mainLayout.setRowStretch(5, 1)
#         mainLayout.setRowStretch(6, 1)
#         mainLayout.setColumnStretch(0, 8)
#         mainLayout.setColumnStretch(1, 1)
#         mainLayout.setColumnStretch(2, 1)
#         mainLayout.setColumnStretch(3, 1)
        self.setLayout(mainLayout)



#Integrator Setting
    
class mainWidget(QWidget):
#class mainWindow(QWidget):
    def __init__(self, parent=None):
        super (mainWidget, self).__init__(parent)
        #super (mainWindow, self).__init__(parent)
        self.setWindowTitle(TITLE_TEXT)
        # self.comport = connectBlock("USB Connection")
        ###self.plot = output2Plot()
        self.tabPlot = TabPlot()

        
        # self.FHedit = editBlock("File Header")
        # self.tabAll = TabAll()
        # self.Signal = Signal_Read_Group()
        # self.runText = QLabel("Run Index = ")
        # self.runText.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
        # self.runIndex = QLabel("0")
        # #self.resetBtn = QPushButton("Reset Index")
        # self.DCmode = QPushButton("DC mode")
        # self.startScan = QPushButton("Start Scan")
        # self.stop = QPushButton("Stop")

        # self.DCmode.setEnabled(False)
        # self.startScan.setEnabled(False)
        # self.stop.setEnabled(False)

        # w = QWidget()
        # self.picout = QLabel(w)
        # lg = QPixmap(LOGO_FILENAME)
        # logo = lg.scaled(500, 90, Qt.KeepAspectRatio)
        # self.picout.setPixmap(logo)

        self.main_UI()

    def main_UI(self):
        mainLayout = QGridLayout()
        mainLayout.addWidget(self.tabPlot,0,0,1,1)
        # mainLayout.addWidget(self.comport.layout2(),0,1,1,1)
        # mainLayout.addWidget(self.FHedit, 0,2,1,2)
        # mainLayout.addWidget(self.tabAll,1,1,1,3)
        # mainLayout.addWidget(self.Signal,2,1,1,3)
        # mainLayout.addWidget(self.runText,3,1,1,1)
        # mainLayout.addWidget(self.runIndex,3,2,1,1)
        # ##mainLayout.addWidget(self.resetBtn,4,3,1,1)
        # mainLayout.addWidget(self.DCmode,4,1,1,1)
        # mainLayout.addWidget(self.startScan,4,2,1,1)
        # mainLayout.addWidget(self.stop,4,3,1,1)
        # mainLayout.addWidget(self.picout,5,1,1,3)
        # mainLayout.setRowStretch(0, 1)
        # mainLayout.setRowStretch(1, 1)
        # mainLayout.setRowStretch(2, 3)
        # mainLayout.setRowStretch(3, 1)
        # mainLayout.setRowStretch(4, 1)
        # mainLayout.setRowStretch(5, 1)
        # mainLayout.setRowStretch(6, 1)
        # mainLayout.setColumnStretch(0, 8)
        # mainLayout.setColumnStretch(1, 1)
        # mainLayout.setColumnStretch(2, 1)
        # mainLayout.setColumnStretch(3, 1)
        self.setLayout(mainLayout)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    main = mainWidget()
    main.show()
    os._exit(app.exec_())
